https://freesound.org/

- Cartoon_Punch_02.wav by RSilveira_88
  https://freesound.org/people/RSilveira_88/sounds/216198/

- Footstep_Water_03.wav by LittleRobotSoundFactory
  https://freesound.org/people/LittleRobotSoundFactory/sounds/270429/

- Footsteps by SoundFX.studio
  https://freesound.org/people/SoundFX.studio/sounds/456273/

-------------------

http://soundeffects.wikia.com/wiki/Anime_Wow_Sound

- Anime_Wow_Sound.oga