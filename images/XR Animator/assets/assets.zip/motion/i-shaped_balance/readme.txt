クリエイティブ・コモンズ・ゼロ
https://creativecommons.org/publicdomain/zero/1.0/deed.ja

このポーズデータとモーションデータは、たとえ営利目的であっても、許可を得ずに複製、改変・翻案、配布することができます。

CC0は、いかなる場合であっても、いかなる者の有する特許権または商標権にも影響はなく、また作品がどのように利用されるかに関して第三者が保有している可能性のある権利（パブリシティ権やプライバシー権 などを含む。）への影響はありません。

適用法令上認められる最大限の範囲で、このデータについて一切の保証をせず、またこのデータのいかなる利用に関する責任も負いません。 


CC0
https://creativecommons.org/publicdomain/zero/1.0

You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.

You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission. See Other Information below.

In no way are the patent or trademark rights of any person affected by CC0, nor are the rights that other persons may have in the work or in how the work is used, such as publicity or privacy rights.

Unless expressly stated otherwise, the person who associated a work with this deed makes no warranties about the work, and disclaims liability for all uses of the work, to the fullest extent permitted by applicable law. 